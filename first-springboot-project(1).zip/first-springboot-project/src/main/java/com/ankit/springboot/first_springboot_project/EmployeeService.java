package com.ankit.springboot.first_springboot_project;

import java.util.ArrayList;
import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;


	public List<Employee> getAll()
	{
		List<Employee> employeeRecords = new ArrayList<>();
		employeeRecords = (List<Employee>) employeeRepository.findAll();
		return employeeRecords;
	}


	public Employee getEmployee(String id){  
		return employeeRepository.findOne(id);  
	}  
	
	public void updateEmployee(Employee employeeRecord){  
		deleteEmployee(employeeRecord.getEmpId());
		employeeRepository.save(employeeRecord);  
	}  
	
	public void addEmployee(Employee employeeRecord){  
		employeeRepository.save(employeeRecord);  
	}  
	public void deleteEmployee(String id){
		employeeRepository.delete(id);  
	} 

}
