package com.ankit.springboot.first_springboot_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.web.bind.annotation.CrossOrigin;

/**
 * Hello world!
 *
 */
@CrossOrigin(origins = "http://localhost:8080")
@EnableJpaAuditing
@SpringBootApplication
public class App 
{
	public static void main( String[] args )
	{
		System.out.println( "Hello World!" );
		SpringApplication.run(App.class, args);
	}
}
